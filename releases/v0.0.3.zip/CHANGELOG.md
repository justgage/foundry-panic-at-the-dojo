# CHANGELOG

## 0.0.1

- Initial version, mostly just the basic character sheet working, with basic version of stances, forms, and archetypes
